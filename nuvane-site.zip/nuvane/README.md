# NUVANE — AI Creative Studio

One-page studio site: cinematic art direction, GSAP scroll choreography, five languages,
light + dark. Built on the existing architecture — nothing was rebuilt to get here.

`Next.js 15 (App Router, JS) · Tailwind v4 · GSAP + ScrollTrigger · Lenis · three.js`

---

## Run it

```bash
npm install
npm run dev          # http://localhost:3000
npm run build        # production build
npm run lint         # eslint (next config)
npm run i18n:audit   # every dictionary must match en key-for-key
```

No env vars, no backend, no API. Media lives in `public/media`.

---

## Layout

```
src/
  app/layout.js        metadata, pre-paint bootstrap (theme + language + motion tier), noscript reset
  app/page.js          section composition
  app/globals.css      tokens, every component style, the light tier, the static tier
  components/          Hero HeroScene Navbar LanguageSwitcher ThemeToggle LocaleSync
                       Capabilities Projects ProjectCard Technology FinalCTA Footer
                       Seam Ticker ScrollProgress Preloader Atmosphere CustomCursor
                       MagneticButton Reveal SmoothScroll SkipLink
  data/site.js         language-independent facts: contact, media, ids, anchors
  i18n/config.js       the five languages, short/native labels, <html lang> tags, locales
  i18n/dictionaries/   en.js (authored source) · es · zh · de · fr
  i18n/index.js        registry + fallback fill (missing key → English, never `undefined`)
  i18n/prefs.js        the store: language + theme, persistence, notifications
  i18n/use-copy.js     hooks that stitch copy onto technical data
  lib/                 animations, scroll, boot latch, motion tiers, cursor, magnetize, pointer
scripts/i18n-audit.mjs shape check for the dictionaries
```

## Languages

Five dictionaries, one shape, plain objects — no i18n library, no provider tree.

* `useCopy()` returns the active dictionary; `useLang()` returns its code.
* Both are `useSyncExternalStore` subscriptions to one small module store, so a switch re-renders
  text only: no remount, no scroll jump, no reload — and running timelines keep their inline
  transforms, because heading lines are keyed by position instead of by text.
* Preference key: `localStorage['language']`. With nothing stored the browser language is used,
  then English.
* `<html lang>` / `data-lang` are written by an inline script in `<head>` before the first paint,
  so a returning visitor in `de` never sees an English frame.
* Masked display lines are sized by `--type-scale` per language (`de .90`, `fr .95`, `es .94`,
  `zh 1.04`); non-English lines may break inside a mask rather than overflow the viewport.
* Chinese renders from the system CJK stack — no webfont is downloaded for it, and mono tracking
  opens up so Hanzi stays legible at 10 px.
* `LocaleSync` owns the shared side effects: `document.title`, description, `og:description`,
  `theme-color`, and one `ScrollTrigger.refresh()` per switch (translated copy changes section
  heights, so pinned rails and scrub ranges must be re-measured — the scroll position does not move).
* Adding a language = add `dictionaries/xx.js` mirroring `en.js`, list it in `config.js`
  (LANGS / LANG_META / LOCALES), add the tag to the bootstrap script, run `npm run i18n:audit`.

## Theme

Dark is the authored default; light is the same page in paper and ink.

* Everything derives from ten channel triplets (`--bg-rgb`, `--fg-rgb`, `--ember-rgb`, …) declared
  on `:root` and re-declared once under `html[data-theme='light']`. `@theme` colours are built from
  those channels, so every Tailwind utility (`text-mist`, `bg-void`, `border-ember/30`) follows
  automatically — one attribute flips the page.
* No React state is involved: `ThemeToggle` writes one attribute. The 260 ms cross-fade is a
  temporary class (`is-theme-anim`) that puts colour-only transitions on the tree for the length of
  the switch, then removes itself so it never interferes with scroll-driven states. Colour
  properties only — no geometry, no filters.
* The WebGL hero cannot read CSS variables: it samples its palette from a small table and re-tints
  on a store subscription (additive light on void, normal ink on paper) without rebuilding geometry.
* Preference key: `localStorage['theme']`; with nothing stored the OS preference is followed, and
  `matchMedia` keeps tracking it until the visitor chooses. Reduced motion flattens the fade.

## Performance rules this codebase keeps

* Scroll-linked state is written to the DOM (classList / transform / textContent), never through
  React state; one ScrollTrigger owns each behaviour and none is duplicated.
* Pointer work rides `gsap.quickTo` on a shared bus; no `mousemove`/`scroll` handler sets state.
* Animated properties are `transform`, `opacity` and the independent `scale`/`translate`/`rotate` —
  never `width`, `top`, `margin`, `filter` — so nothing re-lays-out while the page scrolls.
* Every component cleans up inside `gsap.context()`; listeners the context cannot revert (`focusin`,
  `nebula:lang`, `visibilitychange`, `resize`) are removed by hand in the same effect, and DOM
  listeners whose state lives inside that closure use an effect-scoped handle.
* Mobile drops the pinned rail, the custom cursor, magnetics and 3D subdivision; the hero entrance
  travels 38 % as far. `prefers-reduced-motion` removes all of it and shows every reveal finished —
  with JS off, the `<noscript>` block does the same.
* First Load JS ≈ 183 kB: that includes all four non-English dictionaries (≈13 kB gzipped of prose),
  chosen deliberately over a network round-trip so a switch is instant and works offline. Images stay
  lazy except the first rail plate; the grain layer is a static SVG noise, not a filter.

## Copy ownership

`src/data/site.js` holds facts — contact, media paths, intrinsic sizes, anchors, ids — and nothing
that gets translated. All prose lives in `src/i18n/dictionaries/en.js`; the other four mirror it.
Platform names (`INSTAGRAM`, `WEBGL`, `RUST`) and stack chips stay untranslated on purpose.
Component names, CSS classes, the internal `nebula:lang` event and `window.nebulaLenis` are
implementation detail and were left alone.
