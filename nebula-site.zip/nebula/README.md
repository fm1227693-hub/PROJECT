# NEBULA — AI Creative Studio

Kino uslubidagi (cinematic) immersiv landing: Next.js App Router + Tailwind v4 + GSAP/ScrollTrigger + Lenis + Three.js.

## Ishga tushirish / Run

```bash
npm install      # yoki: npm ci
npm run dev      # http://localhost:3000
npm run build && npm start
```

Node 18.18+ (Next 15 talabi). Shu fayl `node_modules` va `.next` ixtisos qilingan holda yuborilgan — ular `npm install` bilan qayta yaratiladi.

## Tuzilma

```
src/app/layout.js      pre-paint bootstrap (motion tier), Preloader, Atmosphere, Navbar,
                       CustomCursor, ScrollProgress, SmoothScroll, grain
src/app/page.js        Hero → Capabilities → Projects → Technology → Final CTA → Footer
src/app/globals.css    dizayn tizimi: tokenlar, tipografiya, har bir blok uchun CSS
src/components/        barcha seksiya va interfeys komponentlari
src/lib/               animations.js (EASE, depth, typeReveal, mediaReveal, countUp,
                       drawSeams, typeSpread) · pointer.js (pointer bus) · scroll.js
                       (scroll bus + scrollToSection) · boot.js · cursor.js · magnetize.js
                       · motion.js (tier/matchMedia hooklari)
src/data/site.js       BUTUN matn va ma'lumot shu yerda
public/media/          hero/aura/synth/orbit kadr lari
```

## Animatsiya mezoni (bir element — bitta egasi)

| Tizim | Vazifasi |
|---|---|
| GSAP + ScrollTrigger | scrub, pin, parallax, reveal, magnetic |
| Motion (framer-motion) | mobil sheet kabi React UI o'tishlari |
| CSS | hover/focus, state (`.is-scrolled`, `[data-tone]`) |
| Three.js | bitta WebGL sahnasi (hero) |

## Performans qoidalari

- Faqat `transform` / `opacity` / `scale` / `clip-path` animatsiyasi.
- Scroll yoki pointer bo'yicha React state yangilanmaydi — hammasi to'g'ridan-to'g'ri DOMga yoziladi.
- Bitta RAF: GSAP ticker Lenisni ham, ScrollTrigger'ni ham shu yerda yuritadi.
- WebGL faqat hero ekranda va tab ko'rinarli bo'lganda render qiladi.
- `prefers-reduced-motion`: kursor, magnetik tugmalar, pin, parallax, preloader o'chadi; kontent to'liq ko'rinadi.
- Desktop UI (kursor, magnetics, horizontal rail, pinned stage) katta ekranlarga, mobil vertal ro'yxatga ajratilgan.
