import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

async function ready(page) {
  await page.goto('/');
  await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
  await page.waitForFunction(() => document.fonts.status === 'loaded');
  await page.waitForTimeout(2800);
}

async function navigateTo(page, id, isMobile) {
  if (isMobile) {
    await page.getByRole('button', { name: 'Open menu' }).click();
    await page.locator(`.mobile-menu a[href$="#${id}"]`).click();
  } else await page.locator(`.desktop-nav a[href$="#${id}"]`).click();
  await page.waitForTimeout(1500);
}

test('renders the complete experience without runtime errors or horizontal overflow', async ({ page, isMobile }) => {
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
  await ready(page);
  await expect(page).toHaveTitle(/NEBULA.*AI Creative Studio/);
  await expect(page.locator('main > section')).toHaveCount(5);
  await expect(page.locator('header')).toHaveCount(1);
  await expect(page.locator('footer')).toHaveCount(1);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  if (isMobile) {
    await expect(page.locator('.pin-spacer')).toHaveCount(0);
    await expect(page.locator('.custom-cursor')).toBeHidden();
  } else {
    await expect(page.locator('.pin-spacer')).toHaveCount(2);
    await expect(page.locator('html')).toHaveClass(/lenis/);
  }
  for (const id of ['capabilities', 'work', 'about', 'contact']) {
    await navigateTo(page, id, isMobile);
    await expect(page.locator(`#${id}`)).toBeInViewport();
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  }
  await expect(page.locator('.navbar')).toHaveClass(/navbar--compact/);
  expect(errors).toEqual([]);
});

test('capabilities and technology can be explored with the keyboard', async ({ page, isMobile }) => {
  await ready(page);
  await navigateTo(page, 'capabilities', isMobile);
  await page.locator('#cap-tab-1').click();
  await expect(page.locator('#capability-detail')).toContainText('Product strategy');
  await page.keyboard.press('ArrowDown');
  await expect(page.locator('#cap-tab-2')).toHaveAttribute('aria-selected', 'true');
  await expect(page.locator('#capability-detail')).toContainText('Spatial experiences');
  await navigateTo(page, 'about', isMobile);
  await page.locator('#system-tab-2').click();
  await expect(page.locator('#system-tab-2')).toHaveAttribute('aria-selected', 'true');
  await expect(page.locator('#system-detail')).toContainText('Remarkable underneath');
  await page.keyboard.press('ArrowRight');
  await expect(page.locator('#system-tab-3')).toHaveAttribute('aria-selected', 'true');
  await expect(page.locator('.system-word')).toHaveText('MOTION');
});

test('project stories open, switch projects, and restore focus on escape', async ({ page, isMobile }) => {
  await ready(page);
  await navigateTo(page, 'work', isMobile);
  const trigger = page.getByRole('button', { name: 'Explore AURA project' });
  await trigger.click();
  const dialog = page.getByRole('dialog');
  await expect(dialog).toBeVisible();
  await expect(dialog.getByRole('heading', { name: 'AURA.' })).toBeVisible();
  await expect(dialog).toContainText('A self-initiated concept.');
  await dialog.getByRole('button', { name: 'Next world / SYNTH' }).click();
  await expect(dialog.getByRole('heading', { name: 'SYNTH.' })).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(dialog).toHaveCount(0);
  await expect(trigger).toBeFocused();
});

test('inquiry validates inputs and creates a real, encoded email draft', async ({ page, isMobile }) => {
  await ready(page);
  if (isMobile) {
    await page.getByRole('button', { name: 'Open menu' }).click();
    await page.locator('.mobile-menu').getByRole('button', { name: 'Start a project' }).click();
  } else await page.locator('.nav-cta').click();
  const dialog = page.getByRole('dialog');
  await expect(dialog).toBeVisible();
  await dialog.getByRole('button', { name: 'Prepare project brief' }).click();
  await expect(dialog.locator('#inquiry-name')).toBeFocused();
  await dialog.getByLabel('Your name').fill('Alex Morgan');
  await dialog.getByLabel('Email address').fill('alex@example.com');
  await dialog.getByText('Digital product', { exact: true }).click();
  await dialog.getByLabel('A working budget').selectOption('$25k–$50k');
  await dialog.getByLabel('Tell us a little about your idea').fill('An interactive creative tool that helps artists explore generative sound.');
  await dialog.getByRole('button', { name: 'Prepare project brief' }).click();
  await expect(dialog.getByRole('heading')).toContainText('GREAT THINGS');
  await expect(dialog).toContainText('Nothing has been sent or stored');
  const mailto = await dialog.getByRole('link', { name: 'Open email draft' }).getAttribute('href');
  expect(mailto).toMatch(/^mailto:hello@nebula\.studio\?subject=/);
  expect(decodeURIComponent(mailto)).toContain('alex@example.com');
  expect(decodeURIComponent(mailto)).toContain('Digital product');
  await dialog.getByText('Review your brief').click();
  await expect(dialog.locator('pre')).toContainText('An interactive creative tool');
  await dialog.getByRole('button', { name: 'Close dialog' }).click();
  await expect(dialog).toHaveCount(0);
});

test('desktop gallery actually scrubs between all three worlds', async ({ page, isMobile }) => {
  test.skip(isMobile, 'Mobile deliberately uses a native vertical list.');
  await ready(page);
  await navigateTo(page, 'work', false);
  const next = page.getByRole('button', { name: 'Next project', exact: true });
  await next.click();
  await expect(page.locator('.work-progress > span').first()).toContainText('02');
  await expect(page.locator('.project-track')).not.toHaveCSS('transform', 'none');
  await next.click();
  await expect(page.locator('.work-progress > span').first()).toContainText('03');
  await expect(next).toBeDisabled();
  await page.getByRole('button', { name: 'Explore ORBIT project' }).click();
  await expect(page.getByRole('dialog').getByRole('heading', { name: 'ORBIT.' })).toBeVisible();
});

test('reduced motion preserves every section without pinning, smooth scroll, or custom cursor', async ({ page, isMobile }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await ready(page);
  await expect(page.locator('.pin-spacer')).toHaveCount(0);
  await expect(page.locator('html')).not.toHaveClass(/lenis|has-custom-cursor/);
  await navigateTo(page, 'work', isMobile);
  const images = page.locator('.project-reveal');
  for (const image of await images.all()) await expect(image).toHaveCSS('clip-path', 'none');
  const boxes = await page.locator('.project-card').evaluateAll(cards => cards.map(card => card.getBoundingClientRect().top));
  expect(boxes[1]).toBeGreaterThan(boxes[0]);
  expect(boxes[2]).toBeGreaterThan(boxes[1]);
  await page.locator('#system-tab-3').click();
  await expect(page.locator('#system-tab-3')).toHaveAttribute('aria-selected', 'true');
});

test('has no serious or critical accessibility issues', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await ready(page);
  const result = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze();
  expect(result.violations).toEqual([]);
  await page.getByRole('button', { name: 'Let’s talk', exact: true }).click();
  await expect(page.getByRole('dialog')).toBeVisible();
  const dialogResult = await new AxeBuilder({ page }).include('dialog').withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze();
  expect(dialogResult.violations).toEqual([]);
});

test('mobile menu and a warm-loaded dialog hand off scroll lock safely', async ({ page, isMobile }) => {
  test.skip(!isMobile, 'A mobile-menu regression check.');
  await ready(page);
  for (let cycle = 0; cycle < 2; cycle += 1) {
    await page.getByRole('button', { name: 'Open menu' }).click();
    await page.locator('.mobile-menu').getByRole('button', { name: 'Start a project' }).click();
    await expect(page.getByRole('dialog')).toBeVisible();
    await expect(page.locator('html')).toHaveCSS('overflow-y', 'hidden');
    await page.getByRole('button', { name: 'Close dialog' }).click();
    await expect(page.getByRole('dialog')).toHaveCount(0);
    expect(await page.locator('html').evaluate(element => element.style.overflow)).toBe('');
  }
  await page.getByRole('button', { name: 'Open menu' }).click();
  await page.keyboard.press('Escape');
  await expect(page.locator('.mobile-menu')).toHaveCount(0);
  await expect(page.getByRole('button', { name: 'Open menu' })).toBeFocused();
});

test('responsive and reduced-motion switches clean up and recreate only two pins', async ({ page, isMobile }) => {
  test.skip(isMobile, 'Desktop breakpoint lifecycle test.');
  await ready(page);
  for (let cycle = 0; cycle < 3; cycle += 1) {
    await page.setViewportSize({ width: 768, height: 1024 });
    await expect(page.locator('.pin-spacer')).toHaveCount(0);
    await expect(page.locator('html')).not.toHaveClass(/lenis|has-custom-cursor/);
    await page.setViewportSize({ width: 1440, height: 1000 });
    await expect(page.locator('.pin-spacer')).toHaveCount(2);
  }
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await expect(page.locator('.pin-spacer')).toHaveCount(0);
  await page.emulateMedia({ reducedMotion: 'no-preference' });
  await expect(page.locator('.pin-spacer')).toHaveCount(2);
});

test('branded 404 navigation returns to a working home experience', async ({ page, isMobile }) => {
  const response = await page.goto('/a-world-not-yet-built');
  expect(response.status()).toBe(404);
  await expect(page.getByRole('heading', { level: 1 })).toContainText('UNWRITTEN');
  await page.getByRole('link', { name: 'NEBULA home', exact: true }).click();
  await expect(page.locator('#hero-heading')).toBeVisible();
  await page.waitForTimeout(2800);
  await navigateTo(page, 'work', isMobile);
  await expect(page.locator('#work')).toBeInViewport();
  await expect(page.locator('.pin-spacer')).toHaveCount(isMobile ? 0 : 2);
});

test('small phones, tablets, and wide desktops remain within the viewport', async ({ page, isMobile }) => {
  test.skip(isMobile, 'Resize coverage uses a desktop browser context.');
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await ready(page);
  for (const width of [320, 360, 768, 1024, 1280, 1920]) {
    await page.setViewportSize({ width, height: 900 });
    // Device-metric changes and the CSS viewport settle on the next browser frame.
    await expect.poll(() => page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    await page.locator('footer').scrollIntoViewIfNeeded();
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  }
});

test('a touch tablet uses vertical projects rather than a forced horizontal pin', async ({ browser, isMobile }) => {
  test.skip(isMobile, 'One dedicated touch-tablet context is sufficient.');
  const context = await browser.newContext({ viewport: { width: 1024, height: 1366 }, isMobile: true, hasTouch: true });
  const page = await context.newPage();
  await page.goto(process.env.TEST_BASE_URL || 'http://localhost:3000');
  await expect(page.locator('#hero-heading')).toBeVisible();
  await expect(page.locator('.pin-spacer')).toHaveCount(0);
  await expect(page.locator('html')).not.toHaveClass(/lenis|has-custom-cursor/);
  const positions = await page.locator('.project-card').evaluateAll(cards => cards.map(card => card.getBoundingClientRect().top));
  expect(positions[1]).toBeGreaterThan(positions[0]);
  expect(positions[2]).toBeGreaterThan(positions[1]);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await context.close();
});
