# NEBULA® — AI Creative Studio

An original, editorial creative-studio experience built with **Next.js App Router, React, JavaScript, Tailwind CSS, GSAP / ScrollTrigger, and Lenis**. Near-black, porcelain typography, and ember-orange detail. No component-library UI, WebGL renderer, external font requests, or tracking scripts.

## Run

Requires Node.js 22+.

```bash
npm ci
npm run dev       # http://localhost:3000, bound to 0.0.0.0
npm run lint
npm run build
npm start         # production server, bound to 0.0.0.0
```

The development server accepts `*.e2b.app` preview hosts. Browser-facing links and assets use same-origin URLs. Vercel detects the Next.js framework through `vercel.json`; there are no legacy SPA rewrites.

## The experience

Exactly seven chapters: navbar, hero, capabilities, projects, technology, final invitation, footer.

- **Hero:** GSAP timeline for atmosphere, line reveals, copy, actions, and sculptural entrance; transform-only desktop parallax on separate visual layers.
- **Capabilities:** four editorial rows, scroll-driven active index, selectable service details, and arrow-key navigation. Selection updates only at section boundaries or deliberate input.
- **Projects:** three cinematic frames in a pinned, scrubbed desktop gallery. Controls and keyboard focus scroll to the relevant frame. Native vertical list on mobile, shorter viewports, and reduced motion. One-time clip-path / image reveals.
- **Project explorations:** accessible native-dialog case studies, next-project navigation, and a direct path to an inquiry. These are clearly identified as independent concepts—not fabricated client work or results.
- **Connected disciplines:** one lightweight SVG orbital system, a short pinned AI → design → code → motion story, and accessible selection tabs. No particle system.
- **Inquiry:** validated project brief with name, email, service, optional budget, and idea. Produces an encoded `mailto:` draft, offers clipboard copy and a selectable plain-text preview. **Nothing is submitted, logged, or stored.** An email application is needed to send the draft. There is no pretend form-submission backend.
- **Navigation:** responsive mobile menu, keyboard focus containment, Escape handling, active section, compact glass state, and smooth anchor navigation.

## Animation and performance architecture

- **One animation clock:** GSAP's ticker also drives Lenis. No independent `requestAnimationFrame` loops in application code.
- **One pointer-move listener:** the custom cursor and magnetic CTAs share a single system. `quickTo` setters mutate transforms; React never receives pointer coordinates. Maximum magnetic movement is 8px.
- **No per-frame scroll state:** GSAP owns scroll transforms. React state changes only at discrete capability / discipline boundaries and for UI actions.
- **Clear ownership:** different wrappers own image hover, entrance, ambient motion, and parallax. No competing animation engines on the same property.
- Every animation setup has `gsap.context()` / `gsap.matchMedia()` cleanup. Observers, event listeners, ticker callbacks, and magnetic tweens are disposed.
- The sole looping sculpture tween pauses outside the viewport and when the document is hidden. Only the tiny CSS availability indicator pulses elsewhere.
- No pinning, cursor, magnetic effects, smooth-wheel interception, or ambient sculpture motion on mobile. Touch scrolling remains native.
- `prefers-reduced-motion` disables cinematic sequences and uses the complete static composition. Selection, menus, dialogs, links, and forms remain usable.
- Self-hosted variable fonts total approximately **69 KB**. The four optimized WebP artworks total approximately **232 KB** before Next.js responsive optimization. The hero is preloaded; project images are lazy-loaded with reserved dimensions.

A 60 FPS target is a design constraint, not a blanket hardware guarantee. Validate on representative physical devices before release; browser automation does not replace real-device profiling.

## Project structure

```text
app/
  layout.js             fonts, SEO, shared site shell
  page.js               the five main content sections
  globals.css           tokens, editorial styling, responsive / reduced motion
  not-found.js          branded 404
  robots.js, sitemap.js  metadata routes
components/
  Navbar.jsx, Hero.jsx, HeroScene.jsx
  Capabilities.jsx, Projects.jsx, ProjectCard.jsx
  Technology.jsx, FinalCTA.jsx, Footer.jsx
  StudioProvider.jsx    discrete dialog actions; dialog code is lazy-loaded
  StudioDialog.jsx      accessible stories and project inquiry
  SmoothScroll.jsx, CustomCursor.jsx
  MagneticButton.jsx, SectionLabel.jsx, Icons.jsx
lib/
  animations.js         shared GSAP registration / easing / media queries
  scroll.js             shared Lenis reference and navigation helpers
  site.js               editable studio, capabilities, project, and technology data
public/
  images/               compressed, replaceable artwork
  fonts/                self-hosted variable fonts and OFL licenses
scripts/, tests/        visual inspection and browser tests
```

Tailwind v4 is configured through PostCSS and supplies the utility / theme layer. The art-directed compositions use named CSS classes so animation targets and responsive behavior stay explicit. Motion and Three.js are intentionally omitted: they would add weight without improving these particular interactions.

## Before a real launch

1. Set the actual studio email, location, and owned social-profile URLs in `lib/site.js`. The included social URLs are platform destinations, not claimed NEBULA accounts.
2. Set `NEXT_PUBLIC_SITE_URL` to the production origin (see `.env.example`). The default `nebula.studio` is sample brand configuration.
3. Replace the three independent project concepts with approved work if needed. Titles, image paths, alt text, copy, and metadata are centralized in `lib/site.js`.
4. Replace AI-generated placeholder artworks in `public/images/` with approved brand assets if desired. Retain the font licenses when redistributing the fonts.
5. If server-delivered inquiries are required, connect a real email / CRM service with server-side validation, rate limiting, spam protection, and an appropriate privacy notice. Do not change the current draft confirmation into a false “sent” message.

## Browser verification

```bash
npx playwright install chromium
npm run dev
npm run test:e2e
```

The suite covers desktop and mobile navigation, overflow, the live gallery, both tab systems, project dialogs, focus restoration, form validation / email drafts, reduced motion, and axe accessibility checks.

To test a running production server:

```bash
TEST_BASE_URL=http://localhost:3000 npm run test:e2e
```

For a minimal Linux sandbox where Playwright's download host is unavailable, the test-only bundled Chromium can be used. This opt-in configuration uses CPU rasterization instead of a forced Vulkan GPU emulator:

```bash
NEBULA_SANDBOX_BROWSER=1 npm run test:e2e
NEBULA_SANDBOX_BROWSER=1 node scripts/inspect.mjs
NEBULA_SANDBOX_BROWSER=1 node scripts/performance.mjs
```

`PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH` also supports a locally installed browser. Test artifacts and original high-resolution artwork are ignored; only optimized web assets are included in the repository.

Detailed results and measurement limitations are documented in `docs/VERIFICATION.md`.
