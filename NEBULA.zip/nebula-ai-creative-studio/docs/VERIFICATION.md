# Verification notes

Checked against the production Next.js build on 7 September 2026.

## Functional / accessibility checks

The final production run passed **19 applicable browser tests**, with 5 explicitly skipped device-inapplicable cases. The Playwright suite covers:

- All five main sections plus the shared navbar and footer.
- Desktop, mobile, reduced-motion, small-phone, tablet, and wide-screen behavior.
- Actual horizontal project scrubbing and all three project stories.
- Both keyboard-operable capability / discipline selectors.
- Input validation and the encoded project-email draft.
- Native-dialog focus restoration, Escape, and repeated open / close cycles.
- Mobile-menu focus containment and scroll-lock handoff to a cached dialog.
- Responsive / reduced-motion changes remove and recreate exactly two desktop pins.
- No runtime / hydration errors or page-width overflow in the tested journeys.
- Branded 404 navigation back into the full experience.
- Axe WCAG 2 A/AA and WCAG 2.1 AA checks: no detected violations.

Run `npm run test:e2e` for the current results. Platform-inapplicable cases are explicitly skipped, rather than simulated on the wrong device type.

## Animation / memory sample

The reproducible `scripts/performance.mjs` probe samples four seconds of motion in production. Browser automation ran in a minimal Linux sandbox using CPU rasterization, not a physical desktop GPU or mobile device.

| Observation | Desktop, 1440 × 900 | Mobile, 390 × 844 |
| --- | --- | --- |
| Idle frame rate | 60 FPS | 60 FPS |
| Scroll frame rate, mean | 58.3 FPS | 60 FPS |
| Median frame interval | 16.7 ms | 16.7 ms |
| 95th-percentile scroll interval | 16.8 ms | 16.7 ms |
| Layout shift in sampled journey | 0 | 0 |
| React commits during idle animation | 0 | 0 |
| React commits across the scroll journey | 7, at state boundaries | 6, at state boundaries |
| Observed JS long tasks | 0 | 0 |
| DOM nodes after warming a dialog | 694 | 688 |
| DOM nodes after 5 more dialog cycles | 694 | 688 |
| Event listeners after warming a dialog | 408 | 395 |
| Event listeners after 5 more dialog cycles | 408 | 395 |

Initial JS heap was approximately 3.8 MB desktop / 3.7 MB mobile. Loading the on-demand dialog increases the heap as expected; repeated warm cycles did not accumulate DOM nodes or event listeners. Scroll lock was correctly released after every cycle.

The desktop probe uses browser-synthesized wheel input; the mobile sample uses native scroll positions without Lenis. These measurements are a development sample—not a Lighthouse score, field Core Web Vitals report, or a guarantee of frame rate on every device. Test representative physical phones, browsers, and real network conditions before a public launch.

## Delivery checks

- `npm run lint` passes.
- `npm run build` statically prerenders the landing page, 404, robots, and sitemap routes.
- `npm audit` reports no known dependency vulnerabilities at verification time.
- Only optimized web assets are included; the original generated images, screenshots, and browser reports are ignored.
- No external API, analytics, database, or email-delivery service is contacted by the application. Inquiries explicitly prepare an email draft, never a false “sent” confirmation.

Real contact details, owned social-profile URLs, and the production origin still need to be configured for the studio. See the launch checklist in the README.
