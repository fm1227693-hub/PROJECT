/** Standard Playwright locally; bundled Chromium is an opt-in for minimal Linux sandboxes. */
export async function getBrowserOptions() {
  if (process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH) return { executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH, headless: true };
  if (process.env.NEBULA_SANDBOX_BROWSER !== '1') return { headless: true };
  const { default: chromium, inflate } = await import('@sparticuz/chromium');
  const { dirname, join } = await import('node:path');
  const { createRequire } = await import('node:module');
  const require = createRequire(import.meta.url);
  const binaryDirectory = join(dirname(require.resolve('@sparticuz/chromium')), '../bin');
  const libraries = await inflate(join(binaryDirectory, 'al2023.tar.br'));
  const path = await chromium.executablePath();
  process.env.LD_LIBRARY_PATH = `${join(libraries, 'lib')}${process.env.LD_LIBRARY_PATH ? `:${process.env.LD_LIBRARY_PATH}` : ''}`;
  // The sandbox has no physical GPU. Avoid forcing its Vulkan shader emulator for a 2D site.
  const args = chromium.args.filter((flag) => !['--single-process', '--in-process-gpu', '--disable-web-security', '--allow-running-insecure-content', '--disable-site-isolation-trials', '--ignore-gpu-blocklist', '--enable-unsafe-swiftshader'].includes(flag) && !flag.startsWith('--use-gl=') && !flag.startsWith('--use-angle='));
  args.push('--disable-gpu');
  return { executablePath: path, args, headless: true };
}
