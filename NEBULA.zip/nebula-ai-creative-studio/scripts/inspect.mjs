import { chromium as playwright } from '@playwright/test';
import { getBrowserOptions } from './browser.mjs';
import fs from 'node:fs/promises';

const browser = await playwright.launch(await getBrowserOptions());
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 1 });
const errors = [];
page.on('pageerror', error => errors.push(error.message));
page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
await page.goto('http://localhost:3000', { waitUntil: 'networkidle' });
await page.waitForTimeout(3000);
await fs.mkdir('.art/screenshots', { recursive: true });
await page.screenshot({ path: '.art/screenshots/desktop-hero.png' });
console.log('Initial:', await page.evaluate(() => ({ title: document.title, width: innerWidth, scrollWidth: document.documentElement.scrollWidth, sections: [...document.querySelectorAll('main > section')].map(el => ({ id: el.id, top: Math.round(el.getBoundingClientRect().top + scrollY), height: Math.round(el.getBoundingClientRect().height) })), images: [...document.images].map(img=>({ src: img.getAttribute('alt')?.slice(0,30), loaded: img.complete, naturalWidth: img.naturalWidth })) })));
for (const id of ['capabilities', 'work', 'about', 'contact']) {
  await page.locator(`.desktop-nav a[href$="#${id}"]`).click();
  await page.waitForTimeout(1700);
  await page.mouse.move(1420, 950);
  await page.screenshot({ path: `.art/screenshots/desktop-${id}.png` });
}
await page.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight));
await page.waitForTimeout(1300);
await page.screenshot({ path: '.art/screenshots/desktop-footer.png' });
await page.locator('.nav-cta').click();
await page.locator('dialog[open]').waitFor();
await page.waitForTimeout(650);
await page.screenshot({ path: '.art/screenshots/desktop-inquiry.png' });
await page.getByRole('button', { name: 'Close dialog' }).click();
console.log('Errors:', errors);
const mobile = await browser.newPage({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1, isMobile: true, hasTouch: true });
mobile.on('pageerror', error => errors.push(error.message));
await mobile.goto('http://localhost:3000', { waitUntil: 'networkidle' });
await mobile.waitForTimeout(3000);
await mobile.screenshot({ path: '.art/screenshots/mobile-hero.png' });
// Visit each frame so lazy assets and one-time reveals are present in the full-page capture.
for (const id of ['capabilities', 'project-aura', 'project-synth', 'project-orbit', 'about', 'contact']) {
  await mobile.locator(`#${id}`).scrollIntoViewIfNeeded();
  await mobile.waitForTimeout(1050);
}
await mobile.evaluate(() => window.scrollTo(0, 0));
await mobile.waitForTimeout(500);
await mobile.screenshot({ path: '.art/screenshots/mobile-full.png', fullPage: true });
console.log('Mobile:', await mobile.evaluate(()=>({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,height:document.documentElement.scrollHeight, cursor:getComputedStyle(document.querySelector('.custom-cursor')).display})));
console.log('All errors:', errors);
await browser.close();
