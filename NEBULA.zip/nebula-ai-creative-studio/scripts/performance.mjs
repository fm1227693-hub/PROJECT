import { chromium } from '@playwright/test';
import { getBrowserOptions } from './browser.mjs';
import fs from 'node:fs/promises';

const browser = await chromium.launch(await getBrowserOptions());
const report = {};
for (const [name, viewport, mobile] of [['desktop', { width: 1440, height: 900 }, false], ['mobile', { width: 390, height: 844 }, true]]) {
  const context = await browser.newContext({ viewport, isMobile: mobile, hasTouch: mobile, deviceScaleFactor: 1 });
  const page = await context.newPage();
  await page.addInitScript(() => {
    window.__nebulaProbe = { shifts: 0, lcp: 0, commits: 0, longTasks: [] };
    new PerformanceObserver(list => { for (const entry of list.getEntries()) if (!entry.hadRecentInput) window.__nebulaProbe.shifts += entry.value; }).observe({ type: 'layout-shift', buffered: true });
    new PerformanceObserver(list => { for (const entry of list.getEntries()) window.__nebulaProbe.lcp = entry.startTime; }).observe({ type: 'largest-contentful-paint', buffered: true });
    new PerformanceObserver(list => { for (const entry of list.getEntries()) window.__nebulaProbe.longTasks.push(entry.duration); }).observe({ type: 'longtask', buffered: true });
    window.__REACT_DEVTOOLS_GLOBAL_HOOK__ = { supportsFiber: true, inject: () => 1, onCommitFiberRoot: () => { window.__nebulaProbe.commits += 1; }, onCommitFiberUnmount() {}, onPostCommitFiberRoot() {}, renderers: new Map() };
  });
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.goto(process.env.TEST_BASE_URL || 'http://localhost:3000', { waitUntil: 'networkidle' });
  await page.waitForTimeout(3000);
  const cdp = await context.newCDPSession(page);
  await cdp.send('Performance.enable');
  await cdp.send('HeapProfiler.collectGarbage');
  const baselineMetrics = await cdp.send('Performance.getMetrics');
  const nodeBaseline = await cdp.send('Memory.getDOMCounters');

  async function sampleFrames(shouldScroll) {
    const sampling = page.evaluate(async ({ shouldScroll, mobile }) => {
      const frames = [];
      const commitsBefore = window.__nebulaProbe.commits;
      let previous;
      let first;
      await new Promise(resolve => {
        function sample(now) {
          first ??= now;
          if (previous) frames.push(now - previous);
          previous = now;
          if (shouldScroll && mobile) window.scrollTo(0, (now - first) / 4000 * 4700);
          if (now - first < 4000) requestAnimationFrame(sample);
          else resolve();
        }
        requestAnimationFrame(sample);
      });
      const sorted = [...frames].sort((a, b) => a - b);
      return { frames: frames.length, medianFrameMs: +sorted[Math.floor(sorted.length / 2)].toFixed(2), p95FrameMs: +sorted[Math.floor(sorted.length * .95)].toFixed(2), maxFrameMs: +Math.max(...frames).toFixed(2), meanFps: +(1000 / (frames.reduce((sum, value) => sum + value, 0) / frames.length)).toFixed(1), reactCommits: window.__nebulaProbe.commits - commitsBefore };
    }, { shouldScroll, mobile });
    if (shouldScroll && !mobile) await cdp.send('Input.synthesizeScrollGesture', { x: viewport.width / 2, y: viewport.height / 2, yDistance: -4700, speed: 1600, preventFling: true, gestureSourceType: mobile ? 'touch' : 'mouse' });
    return sampling;
  }
  const idle = await sampleFrames(false);
  const scroll = await sampleFrames(true);
  await page.waitForTimeout(1700);
  // Warm the lazy-loaded dialog, then check its repeated mount/unmount lifecycle.
  await page.locator('.nav-cta').evaluate(button => button.click());
  await page.locator('dialog[open]').waitFor();
  await page.waitForTimeout(600);
  await page.getByRole('button', { name: 'Close dialog' }).click();
  await page.locator('dialog').waitFor({ state: 'detached' });
  await cdp.send('HeapProfiler.collectGarbage');
  const warmedNodes = await cdp.send('Memory.getDOMCounters');
  for (let i = 0; i < 5; i += 1) {
    await page.locator('.nav-cta').evaluate(button => button.click());
    await page.locator('dialog[open]').waitFor();
    await page.waitForTimeout(500);
    await page.getByRole('button', { name: 'Close dialog' }).click();
    await page.locator('dialog').waitFor({ state: 'detached' });
  }
  await cdp.send('HeapProfiler.collectGarbage');
  const finalMetrics = await cdp.send('Performance.getMetrics');
  const finalNodes = await cdp.send('Memory.getDOMCounters');
  const metric = (metrics, key) => metrics.metrics.find(item => item.name === key)?.value;
  report[name] = {
    viewport, idle, scroll,
    ...await page.evaluate(() => ({ cls: +window.__nebulaProbe.shifts.toFixed(5), lcpLocalMs: +window.__nebulaProbe.lcp.toFixed(1), longTasks: window.__nebulaProbe.longTasks.map(value=>+value.toFixed(1)), transferKB: +(performance.getEntriesByType('resource').reduce((sum, entry) => sum + entry.transferSize, 0) / 1024).toFixed(1), scrollY: window.scrollY, pins: document.querySelectorAll('.pin-spacer').length, overflow: document.documentElement.scrollWidth > innerWidth, scrollUnlocked: document.documentElement.style.overflow === '' })),
    initialHeapMB: +(metric(baselineMetrics, 'JSHeapUsedSize') / 1024 / 1024).toFixed(2),
    finalHeapMB: +(metric(finalMetrics, 'JSHeapUsedSize') / 1024 / 1024).toFixed(2),
    initialDOM: nodeBaseline, warmedDOM: warmedNodes, finalDOM: finalNodes, errors,
  };
  console.log(name, JSON.stringify(report[name], null, 2));
  await context.close();
}
await fs.mkdir('.art', { recursive: true });
await fs.writeFile('.art/performance.json', JSON.stringify(report, null, 2));
await browser.close();
