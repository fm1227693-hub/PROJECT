'use client';

import { useLayoutEffect, useRef, useState } from 'react';
import { gsap } from '@/lib/animations';
import { technologies } from '@/lib/site';
import { scrollToPosition } from '@/lib/scroll';
import SectionLabel from './SectionLabel';
import { BrandMark, PlusIcon } from './Icons';

export default function Technology() {
  const ref = useRef(null);
  const stateRef = useRef(null);
  const activeRef = useRef(0);
  const timelineRef = useRef(null);
  const tabsRef = useRef([]);
  const [active, setActive] = useState(0);

  useLayoutEffect(() => {
    const media = gsap.matchMedia();
    const context = gsap.context(() => {
      media.add({ all: 'all', cinematic: '(min-width: 1024px) and (min-height: 740px) and (pointer: fine)', reduced: '(prefers-reduced-motion: reduce)' }, ({ conditions }) => {
        if (conditions.reduced) return;
        gsap.from('.technology-heading > span > span', { yPercent: 105, stagger: 0.08, duration: 0.9, ease: 'power3.out', scrollTrigger: { trigger: ref.current, start: 'top 82%', once: true } });
        gsap.from('.system-visual', { opacity: 0, scale: 0.9, duration: 1.2, ease: 'power3.out', scrollTrigger: { trigger: ref.current, start: 'top 75%', once: true } });
        if (conditions.cinematic) {
          const state = { value: 0 };
          const timeline = gsap.timeline({
            scrollTrigger: { id: 'nebula-system', trigger: '.technology-stage', start: 'top 88px', end: '+=1050', pin: true, scrub: 0.8, anticipatePin: 1 },
          });
          timeline.to('.system-orbits', { rotation: 135, scale: 1.035, duration: 3, ease: 'none' }, 0)
            .to(state, { value: 3, duration: 3, ease: 'none', onUpdate: () => {
              const next = Math.min(3, Math.round(state.value));
              if (next !== activeRef.current) { activeRef.current = next; setActive(next); }
            } }, 0);
          timelineRef.current = timeline;
          return () => { timelineRef.current = null; };
        }
      });
    }, ref);
    return () => { media.revert(); context.revert(); };
  }, []);

  useLayoutEffect(() => {
    const media = gsap.matchMedia();
    const context = gsap.context(() => {
      media.add('(prefers-reduced-motion: no-preference)', () => {
        gsap.from('.system-word-inner', { y: 22, opacity: 0, duration: 0.6, ease: 'power3.out' });
        gsap.from(stateRef.current, { y: 8, opacity: 0, duration: 0.5, ease: 'power3.out' });
      });
    }, ref);
    return () => { media.revert(); context.revert(); };
  }, [active]);

  function choose(index) {
    const trigger = timelineRef.current?.scrollTrigger;
    if (trigger) scrollToPosition(trigger.start + (trigger.end - trigger.start) * (index / 3) + 1);
    else { activeRef.current = index; setActive(index); }
  }

  function handleKeys(event, index) {
    const next = event.key === 'ArrowRight' ? (index + 1) % 4 : event.key === 'ArrowLeft' ? (index + 3) % 4 : event.key === 'Home' ? 0 : event.key === 'End' ? 3 : null;
    if (next === null) return;
    event.preventDefault();
    choose(next);
    tabsRef.current[next]?.focus({ preventScroll: true });
  }

  return (
    <section id="about" ref={ref} className="technology section-shell" aria-labelledby="technology-heading" data-system-state={active}>
      <div className="technology-stage">
        <SectionLabel number="03" right="FOUR DISCIPLINES. ONE NEW DIMENSION.">Our operating system</SectionLabel>
        <div className="technology-content">
          <div className="technology-copy">
            <h2 id="technology-heading" className="technology-heading"><span><span>WHERE</span></span><span><span>EVERYTHING</span></span><span><span className="muted">CONNECTS.</span></span></h2>
            <p className="technology-lead">Human instinct.<br />Machine possibility.</p>
            <p className="technology-description">We don’t work in silos. We build at the intersections—where art meets engineering, and the unexpected becomes possible.</p>
            <div className="technology-signature mono"><BrandMark />Different ways of thinking.<br />One shared obsession.</div>
          </div>
          <div className="system-panel">
            <div className="system-visual" aria-hidden="true">
              <span className="system-corner system-corner--tl"><PlusIcon /></span><span className="system-corner system-corner--br"><PlusIcon /></span>
              <span className="system-overline mono">NEBULA CONNECTIVE SYSTEM®</span>
              <div className="system-orbits">
                <svg viewBox="0 0 600 600" fill="none" className="orbit-svg">
                  <circle cx="300" cy="300" r="246" stroke="currentColor" strokeOpacity=".14" />
                  <circle cx="300" cy="300" r="217" stroke="currentColor" strokeOpacity=".2" strokeDasharray="1 11" />
                  <g stroke="currentColor" strokeOpacity=".27" strokeWidth=".7">
                    {[-60, -30, 0, 30, 60, 90].map((angle) => <ellipse key={angle} cx="300" cy="300" rx="204" ry="76" transform={`rotate(${angle} 300 300)`} />)}
                    <circle cx="300" cy="300" r="204" />
                  </g>
                  <ellipse cx="300" cy="300" rx="268" ry="90" transform="rotate(-35 300 300)" stroke="var(--accent)" strokeOpacity=".55" strokeWidth=".9" />
                  <circle cx="505" cy="143" r="5" fill="var(--accent)" />
                  <circle cx="95" cy="457" r="3" fill="currentColor" />
                  <path d="M300 40v15m0 490v15M40 300h15m490 0h15" stroke="currentColor" strokeOpacity=".5" />
                </svg>
              </div>
              <div className="system-center"><span className="system-core-label mono">{technologies[active].label}</span><span className="system-word"><span key={active} className="system-word-inner">{technologies[active].word}</span></span><span className="system-core-code mono">{technologies[active].code}</span></div>
              <span className="system-axis mono">CONNECTED BY CURIOSITY / N—0{active + 1}</span>
            </div>
            <div className="system-tabs" role="tablist" aria-label="Explore our connected disciplines">
              {technologies.map((technology, index) => <button ref={(element) => { tabsRef.current[index] = element; }} type="button" role="tab" id={`system-tab-${index}`} aria-selected={active === index} aria-controls="system-detail" tabIndex={active === index ? 0 : -1} key={technology.word} className={`system-tab mono ${active === index ? 'is-active' : ''}`} onClick={() => choose(index)} onKeyDown={(event) => handleKeys(event, index)}><span>0{index + 1}</span>{technology.word}<i /></button>)}
            </div>
            <div ref={stateRef} id="system-detail" className="system-description" role="tabpanel" aria-labelledby={`system-tab-${active}`} tabIndex={0}><span className="mono accent">0{active + 1} /</span><p>{technologies[active].description}</p></div>
          </div>
        </div>
      </div>
    </section>
  );
}
