'use client';

import { useLayoutEffect, useRef, useState } from 'react';
import { gsap, ScrollTrigger } from '@/lib/animations';
import { capabilities } from '@/lib/site';
import SectionLabel from './SectionLabel';
import { ArrowIcon, BrandMark } from './Icons';

export default function Capabilities() {
  const ref = useRef(null);
  const detailRef = useRef(null);
  const [active, setActive] = useState(0);
  const itemRefs = useRef([]);

  function select(index) { setActive(index); }

  useLayoutEffect(() => {
    const media = gsap.matchMedia();
    const context = gsap.context(() => {
      media.add({ all: 'all', reduced: '(prefers-reduced-motion: reduce)', desktop: '(min-width: 1024px) and (pointer: fine)' }, ({ conditions }) => {
        if (conditions.reduced) return;
        gsap.from('.cap-heading-line > span', {
          yPercent: 105, duration: 0.9, stagger: 0.1, ease: 'power3.out',
          scrollTrigger: { trigger: '.cap-heading', start: 'top 88%', once: true },
        });
        gsap.from('.cap-intro', {
          y: 22, opacity: 0, duration: 0.8,
          scrollTrigger: { trigger: '.cap-intro', start: 'top 90%', once: true },
        });
        itemRefs.current.forEach((item, index) => {
          gsap.from(item, { y: 24, opacity: 0, duration: 0.65, ease: 'power3.out', scrollTrigger: { trigger: item, start: 'top 92%', once: true } });
          if (conditions.desktop) ScrollTrigger.create({ trigger: item, start: 'top 52%', end: 'bottom 52%', onEnter: () => select(index), onEnterBack: () => select(index) });
        });
      });
    }, ref);
    return () => { media.revert(); context.revert(); };
  }, []);

  useLayoutEffect(() => {
    const context = gsap.context(() => {
      if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
      gsap.from(detailRef.current.children, { y: 10, opacity: 0, stagger: 0.04, duration: 0.45, ease: 'power3.out' });
    }, detailRef);
    return () => context.revert();
  }, [active]);

  function handleKeys(event, index) {
    const next = event.key === 'ArrowDown' ? (index + 1) % 4 : event.key === 'ArrowUp' ? (index + 3) % 4 : event.key === 'Home' ? 0 : event.key === 'End' ? 3 : null;
    if (next === null) return;
    event.preventDefault();
    select(next);
    itemRefs.current[next]?.querySelector('button').focus({ preventScroll: true });
  }

  return (
    <section id="capabilities" ref={ref} className="capabilities section-shell" aria-labelledby="capabilities-heading">
      <SectionLabel number="01" right="A LITTLE VISION. A LOT OF POSSIBILITY.">Our capabilities</SectionLabel>
      <div className="cap-header">
        <h2 className="cap-heading" id="capabilities-heading">
          <span className="cap-heading-line"><span>WE TURN COMPLEX</span></span>
          <span className="cap-heading-line"><span>TECHNOLOGY INTO</span></span>
          <span className="cap-heading-line"><span className="muted">EXPERIENCES.</span></span>
        </h2>
        <p className="cap-intro">Not technology for technology’s sake.<br />We connect the dots between what’s possible and what’s meaningful.</p>
      </div>
      <div className="cap-editorial">
        <div className="cap-aside">
          <div className="cap-aside-sticky">
            <div className="cap-index-visual" aria-hidden="true"><span className="cap-index-outline">0{active + 1}</span><BrandMark className="cap-star" /><span className="cap-index-coordinate mono">N / C—0{active + 1}</span></div>
            <div ref={detailRef} className="cap-detail" role="tabpanel" id="capability-detail" aria-labelledby={`cap-tab-${active}`} tabIndex={0}>
              <span className="mono cap-detail-label">{capabilities[active].detail}</span>
              <ul>{capabilities[active].disciplines.map((discipline) => <li key={discipline}>{discipline}</li>)}</ul>
            </div>
          </div>
        </div>
        <div className="cap-list" role="tablist" aria-label="Explore our capabilities" aria-orientation="vertical">
          {capabilities.map((capability, index) => (
            <div ref={(element) => { itemRefs.current[index] = element; }} key={capability.number} className={`cap-row ${active === index ? 'is-active' : ''}`}>
              <button type="button" className="cap-select" role="tab" id={`cap-tab-${index}`} aria-selected={active === index} aria-controls="capability-detail" tabIndex={active === index ? 0 : -1} onClick={() => select(index)} onKeyDown={(event) => handleKeys(event, index)}>
                <span className="cap-number mono">{capability.number}</span>
                <span className="cap-row-content"><span className="cap-title">{capability.title}</span><span className="cap-description">{capability.description}</span></span>
                <span className="cap-arrow"><ArrowIcon /></span>
              </button>
              <span className="cap-row-progress" aria-hidden="true" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
