import { ArrowIcon } from './Icons';

export default function MagneticButton({ children, href, onClick, variant = 'primary', className = '', arrow = true, type = 'button', ...props }) {
  const Tag = href ? 'a' : 'button';
  return (
    <Tag href={href} onClick={onClick} type={href ? undefined : type} data-magnetic className={`button button--${variant} ${className}`} {...props}>
      <span className="button-label">{children}</span>
      {arrow && <span className="button-arrow"><ArrowIcon /></span>}
    </Tag>
  );
}
