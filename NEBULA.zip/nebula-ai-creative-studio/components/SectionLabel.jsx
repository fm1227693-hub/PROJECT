export default function SectionLabel({ number, children, right }) {
  return (
    <div className="section-label mono">
      <span><span className="section-index">{number} /</span> {children}</span>
      {right && <span className="section-label-right">{right}</span>}
    </div>
  );
}
