'use client';

import Image from 'next/image';
import { useLayoutEffect, useRef, useState } from 'react';
import { gsap } from '@/lib/animations';
import { lockScroll } from '@/lib/scroll';
import { projects, site } from '@/lib/site';
import { ArrowIcon, BrandMark, CloseIcon } from './Icons';
import MagneticButton from './MagneticButton';

function ProjectStory({ project, onContact, onProject }) {
  const next = projects[(projects.findIndex((item) => item.id === project.id) + 1) % projects.length];
  return (
    <div className="project-story" key={project.id}>
      <div className="project-story-image"><Image src={project.image} alt={project.alt} fill sizes="(max-width: 767px) 100vw, 1000px" quality={85} /></div>
      <div className="project-story-content">
        <span className="mono accent">{project.number} / INDEPENDENT STUDIO EXPLORATION</span>
        <div className="project-story-heading"><h2 id="studio-dialog-title" data-initial-focus tabIndex={-1}>{project.title}<span className="accent">.</span></h2><span className="mono">{project.category}<br />{project.year}</span></div>
        <p className="project-story-tagline">{project.tagline}</p>
        <div className="project-story-grid"><div><span className="mono footer-label">THE IDEA</span><p>{project.overview}</p><span className="mono footer-label">THE APPROACH</span><p>{project.approach}</p></div><aside><span className="mono footer-label">WHAT WE EXPLORED</span><ul>{project.disciplines.map((discipline) => <li key={discipline}>{discipline}</li>)}</ul><span className="project-concept-note">A self-initiated concept.<br />Built to explore what comes next.</span></aside></div>
        <p className="project-takeaway">{project.takeaway}</p>
        <div className="project-story-actions"><MagneticButton onClick={onContact}>Create something with us</MagneticButton><button className="next-story mono" type="button" onClick={() => onProject(next)}>Next world / {next.title}<ArrowIcon /></button></div>
      </div>
    </div>
  );
}

function ProjectInquiry() {
  const [brief, setBrief] = useState(null);
  const [copyStatus, setCopyStatus] = useState('');
  const readyRef = useRef(null);

  useLayoutEffect(() => {
    if (brief) readyRef.current?.focus({ preventScroll: true });
  }, [brief]);

  function prepareBrief(event) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const name = String(data.get('name')).trim();
    const email = String(data.get('email')).trim();
    const service = String(data.get('service'));
    const budget = String(data.get('budget') || 'Let’s discuss');
    const idea = String(data.get('idea')).trim();
    if (name.length < 2 || idea.length < 20) {
      const field = event.currentTarget.elements.namedItem(name.length < 2 ? 'name' : 'idea');
      field.setCustomValidity(name.length < 2 ? 'Please enter your name.' : 'Tell us a little more—at least 20 non-padding characters.');
      field.reportValidity();
      return;
    }
    const subject = `A new world: ${service} — ${name}`;
    const body = `Hello NEBULA,\n\nI have an idea I'd love to explore with you.\n\nName: ${name}\nEmail: ${email}\nInterested in: ${service}\nBudget: ${budget}\n\nThe idea:\n${idea}\n\nLet’s build something unexpected.\n${name}`;
    setBrief({ name, body, mailto: `mailto:${site.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}` });
    event.currentTarget.closest('.modal-panel')?.scrollTo({ top: 0 });
  }

  async function copyBrief() {
    try {
      if (!navigator.clipboard) throw new Error('Clipboard unavailable');
      await navigator.clipboard.writeText(brief.body);
      setCopyStatus('Brief copied. Paste it into an email whenever you’re ready.');
    } catch {
      setCopyStatus('Automatic copying isn’t available. Open “Review your brief” below to select and copy the text.');
    }
  }

  if (brief) return (
    <div className="inquiry-content inquiry-ready">
      <BrandMark className="inquiry-mark" />
      <span className="mono accent">YOUR NEXT CHAPTER / READY TO BEGIN</span>
      <h2 ref={readyRef} id="studio-dialog-title" tabIndex={-1}>GREAT THINGS<br />START HERE<span className="accent">.</span></h2>
      <p>Thanks, {brief.name.split(' ')[0]}. Your project brief is ready. Open your email app to review and send it to <a className="text-link" href={`mailto:${site.email}`}>{site.email}</a>.</p>
      <div className="inquiry-ready-actions"><MagneticButton href={brief.mailto}>Open email draft</MagneticButton><button type="button" className="button button--outline" onClick={copyBrief}>Copy brief<ArrowIcon /></button></div>
      <p className="form-note">Nothing has been sent or stored. You’re always in control.</p>
      {copyStatus && <p className="copy-status" role="status">{copyStatus}</p>}
      <details className="brief-preview"><summary className="mono">Review your brief</summary><pre>{brief.body}</pre></details>
      <button type="button" className="text-link mono edit-brief" onClick={() => { setBrief(null); setCopyStatus(''); }}>Start a new brief ↗</button>
    </div>
  );

  return (
    <div className="inquiry-content">
      <span className="mono accent">START A CONVERSATION / MAKE A CONNECTION</span>
      <h2 id="studio-dialog-title" data-initial-focus tabIndex={-1}>WHAT DO YOU<br />HAVE IN MIND<span className="accent">?</span></h2>
      <p className="inquiry-intro">Big ambitions. Early thoughts. Beautifully strange ideas.<br />We’d love to hear yours.</p>
      <form className="inquiry-form" onSubmit={prepareBrief}>
        <div className="form-row"><label htmlFor="inquiry-name"><span className="mono">Your name <span className="accent">*</span></span><input id="inquiry-name" name="name" onInput={(event) => event.currentTarget.setCustomValidity('')} autoComplete="name" placeholder="Alex Morgan" required minLength={2} maxLength={80} /></label><label htmlFor="inquiry-email"><span className="mono">Email address <span className="accent">*</span></span><input id="inquiry-email" name="email" type="email" autoComplete="email" placeholder="alex@yourworld.com" required maxLength={120} /></label></div>
        <fieldset className="service-fieldset"><legend className="mono">What are we creating? <span className="accent">*</span></legend><div className="service-options">{['AI experience', 'Digital product', 'Interactive system', 'Something unexpected'].map((service, index) => <label className="service-option" key={service}><input className="sr-only" type="radio" name="service" value={service} defaultChecked={index === 0} required /><span>{service}</span></label>)}</div></fieldset>
        <label htmlFor="inquiry-budget"><span className="mono">A working budget <span className="optional">/ OPTIONAL</span></span><select id="inquiry-budget" name="budget" defaultValue=""><option value="">Let’s figure it out together</option><option value="Under $25k">Under $25k</option><option value="$25k–$50k">$25k–$50k</option><option value="$50k–$100k">$50k–$100k</option><option value="$100k+">$100k+</option></select></label>
        <label htmlFor="inquiry-idea"><span className="mono">Tell us a little about your idea <span className="accent">*</span></span><textarea id="inquiry-idea" name="idea" onInput={(event) => event.currentTarget.setCustomValidity('')} placeholder="The ambition, the challenge, the what-if…" rows={3} required minLength={20} maxLength={1600} aria-describedby="idea-hint" /><span id="idea-hint" className="form-hint">At least 20 characters. A rough idea is more than enough.</span></label>
        <div className="form-submit"><MagneticButton type="submit">Prepare project brief</MagneticButton><span className="form-note">We’ll prepare an email draft.<br />Nothing is sent automatically.</span></div>
      </form>
    </div>
  );
}

export default function StudioDialog({ dialog, onClose, onContact, onProject }) {
  const ref = useRef(null);
  const panelRef = useRef(null);
  const contextRef = useRef(null);
  const closingRef = useRef(false);

  useLayoutEffect(() => {
    const element = ref.current;
    const previouslyFocused = document.activeElement;
    const releaseScroll = lockScroll();
    element.showModal();
    contextRef.current = gsap.context(() => {
      if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) gsap.from(panelRef.current, { y: 25, opacity: 0, duration: 0.45, ease: 'power3.out' });
    }, ref);
    element.querySelector('[data-initial-focus]')?.focus({ preventScroll: true });
    return () => {
      contextRef.current?.revert();
      element.close();
      releaseScroll();
      if (previouslyFocused?.isConnected && previouslyFocused !== document.body) previouslyFocused.focus({ preventScroll: true });
      else document.querySelector(window.matchMedia('(max-width: 899px)').matches ? '.menu-toggle' : '.nav-cta')?.focus({ preventScroll: true });
    };
  }, []);

  useLayoutEffect(() => {
    panelRef.current?.scrollTo({ top: 0 });
    ref.current?.querySelector('[data-initial-focus]')?.focus({ preventScroll: true });
  }, [dialog]);

  function requestClose() {
    if (closingRef.current) return;
    closingRef.current = true;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) onClose();
    else contextRef.current.add(() => gsap.to(panelRef.current, { y: 18, opacity: 0, duration: 0.22, ease: 'power2.in', onComplete: onClose }));
  }

  return (
    <dialog ref={ref} className="modal-shell" aria-labelledby="studio-dialog-title" onCancel={(event) => { event.preventDefault(); requestClose(); }} onClick={(event) => { if (event.target === event.currentTarget) requestClose(); }}>
      <div ref={panelRef} className={`modal-panel ${dialog.type === 'contact' ? 'modal-panel--inquiry' : ''}`} data-lenis-prevent>
        <button type="button" className="modal-close" aria-label="Close dialog" onClick={requestClose}><CloseIcon /></button>
        {dialog.type === 'project' ? <ProjectStory project={dialog.project} onContact={onContact} onProject={onProject} /> : <ProjectInquiry />}
      </div>
    </dialog>
  );
}
