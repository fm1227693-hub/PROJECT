export function ArrowIcon({ diagonal = true, className = '', ...props }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className={className} aria-hidden="true" {...props}>
      {diagonal ? <path d="M5 19 19 5M5 5h14v14" /> : <path d="M4 12h16m-7-7 7 7-7 7" />}
    </svg>
  );
}

export function BrandMark({ className = '', ...props }) {
  return (
    <svg viewBox="0 0 40 40" fill="currentColor" className={className} aria-hidden="true" {...props}>
      {[0, 45, 90, 135, 180, 225, 270, 315].map((rotation) => (
        <path key={rotation} d="M18 2h4l1 11-3 5-3-5z" transform={`rotate(${rotation} 20 20)`} />
      ))}
    </svg>
  );
}

export function PlusIcon({ className = '' }) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" className={className} aria-hidden="true"><path d="M12 4v16M4 12h16" /></svg>;
}

export function CloseIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18" /></svg>;
}
