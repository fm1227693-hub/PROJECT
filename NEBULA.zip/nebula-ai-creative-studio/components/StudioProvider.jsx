'use client';

import { createContext, useCallback, useContext, useMemo, useState } from 'react';
import dynamic from 'next/dynamic';

const StudioDialog = dynamic(() => import('./StudioDialog'), { ssr: false });
const StudioContext = createContext(null);

export function useStudio() {
  const context = useContext(StudioContext);
  if (!context) throw new Error('Studio actions must be used inside StudioProvider.');
  return context;
}

export default function StudioProvider({ children }) {
  const [dialog, setDialog] = useState(null);
  const openContact = useCallback(() => setDialog({ type: 'contact' }), []);
  const openProject = useCallback((project) => setDialog({ type: 'project', project }), []);
  const closeDialog = useCallback(() => setDialog(null), []);
  const value = useMemo(() => ({ openContact, openProject }), [openContact, openProject]);
  return (
    <StudioContext.Provider value={value}>
      {children}
      {dialog && <StudioDialog dialog={dialog} onClose={closeDialog} onContact={openContact} onProject={openProject} />}
    </StudioContext.Provider>
  );
}
