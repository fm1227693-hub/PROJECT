'use client';

import Image from 'next/image';
import { ArrowIcon, PlusIcon } from './Icons';
import { useStudio } from './StudioProvider';

export default function ProjectCard({ project, index, onFocus }) {
  const { openProject } = useStudio();
  return (
    <article className={`project-card project-card--${project.theme}`}>
      <div className="project-reveal">
        <div className="project-image-hover">
          <Image src={project.image} alt={project.alt} fill className="project-image" sizes="(min-width: 1024px) 68vw, 100vw" quality={85} />
        </div>
        <div className="project-overlay" aria-hidden="true" />
        <span className="project-art-label mono"><PlusIcon />{project.label}</span>
        <span className="project-number" aria-hidden="true">{project.number}</span>
        <span className="project-open-icon"><ArrowIcon /></span>
        <span className="project-art-coordinate mono">N® / {project.year}</span>
      </div>
      <div className="project-meta-reveal">
        <div className="project-meta"><h3 id={`project-${project.id}`}>{project.title}<span className="project-title-dot">.</span></h3><div className="project-category mono"><span>{project.category}</span><span className="project-year">{project.year} ↗</span></div></div>
        <p className="project-description">{project.description}</p>
      </div>
      <button type="button" className="project-hitarea" aria-label={`Explore ${project.title} project`} data-cursor="VIEW" onClick={() => openProject(project)} onFocus={(event) => { if (event.currentTarget.matches(':focus-visible')) onFocus?.(index); }}><span className="sr-only">Explore {project.title}</span></button>
    </article>
  );
}
