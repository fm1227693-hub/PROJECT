'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { gsap, ScrollTrigger } from '@/lib/animations';
import { lockScroll } from '@/lib/scroll';
import { navigation } from '@/lib/site';
import { BrandMark, ArrowIcon, CloseIcon } from './Icons';
import MagneticButton from './MagneticButton';
import { useStudio } from './StudioProvider';

export default function Navbar() {
  const pathname = usePathname();
  const ref = useRef(null);
  const menuRef = useRef(null);
  const toggleRef = useRef(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [active, setActive] = useState('');
  const [compact, setCompact] = useState(false);
  const { openContact } = useStudio();

  useLayoutEffect(() => {
    const context = gsap.context(() => {
      ScrollTrigger.create({
        start: 60, end: 'max',
        onToggle: (self) => setCompact(self.scroll() > 60),
        onRefresh: (self) => setCompact(self.scroll() > 60),
      });
    }, ref);
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) setActive(entry.target.id);
      });
    }, { rootMargin: '-15% 0px -45% 0px' });
    document.querySelectorAll('main > section[id]').forEach((section) => observer.observe(section));
    return () => { context.revert(); observer.disconnect(); };
  }, [pathname]);

  useEffect(() => {
    if (!menuOpen) return;
    const menu = menuRef.current;
    const toggle = toggleRef.current;
    const releaseScroll = lockScroll();
    document.querySelector('main')?.setAttribute('inert', '');
    document.querySelector('footer')?.setAttribute('inert', '');
    const links = menu.querySelectorAll('a, button');
    links[0]?.focus();
    function keydown(event) {
      if (event.key === 'Escape') setMenuOpen(false);
      if (event.key === 'Tab') {
        const focusables = [toggle, ...links];
        const current = focusables.indexOf(document.activeElement);
        if (event.shiftKey && current <= 0) { event.preventDefault(); focusables.at(-1)?.focus(); }
        else if (!event.shiftKey && current === focusables.length - 1) { event.preventDefault(); toggle.focus(); }
      }
    }
    const desktop = window.matchMedia('(min-width: 900px)');
    function handleDesktop(event) { if (event.matches) setMenuOpen(false); }
    desktop.addEventListener('change', handleDesktop);
    document.addEventListener('keydown', keydown);
    return () => {
      releaseScroll();
      document.querySelector('main')?.removeAttribute('inert');
      document.querySelector('footer')?.removeAttribute('inert');
      document.removeEventListener('keydown', keydown);
      desktop.removeEventListener('change', handleDesktop);
      if (!document.querySelector('dialog[open]')) toggle?.focus({ preventScroll: true });
    };
  }, [menuOpen]);

  useLayoutEffect(() => {
    if (!menuOpen) return;
    const context = gsap.context(() => {
      if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
      gsap.from(menuRef.current, { opacity: 0, y: -12, duration: 0.35, ease: 'power3.out' });
      gsap.from('.mobile-nav-link', { y: 22, opacity: 0, stagger: 0.055, duration: 0.55, ease: 'power3.out' });
    }, ref);
    return () => context.revert();
  }, [menuOpen]);

  function inquire() { setMenuOpen(false); openContact(); }
  return (
    <header ref={ref} className={`navbar ${compact ? 'navbar--compact' : ''} ${menuOpen ? 'navbar--open' : ''}`}>
      <div className="nav-shell">
        <Link href="/#home" className="brand" aria-label="NEBULA home" onClick={() => setMenuOpen(false)}><BrandMark /><span>NEBULA<sup>®</sup></span></Link>
        <nav className="desktop-nav" aria-label="Main navigation">
          {navigation.map((link) => <Link key={link.id} className={`nav-link mono ${active === link.id ? 'is-active' : ''}`} href={`/${link.href}`} aria-current={active === link.id ? 'location' : undefined}>{link.label}</Link>)}
        </nav>
        <MagneticButton variant="nav" className="nav-cta" onClick={openContact}>Start a project</MagneticButton>
        <button className="menu-toggle" ref={toggleRef} type="button" aria-expanded={menuOpen} aria-controls="mobile-menu" aria-label={menuOpen ? 'Close menu' : 'Open menu'} onClick={() => setMenuOpen(!menuOpen)}>
          <span className="mono">{menuOpen ? 'Close' : 'Menu'}</span>{menuOpen ? <CloseIcon /> : <span className="menu-lines"><i /><i /></span>}
        </button>
      </div>
      {menuOpen && <nav ref={menuRef} id="mobile-menu" className="mobile-menu" aria-label="Mobile navigation">
        <span className="mono mobile-menu-label">A new perspective starts here.</span>
        {navigation.map((link, index) => <Link key={link.id} className="mobile-nav-link" href={`/${link.href}`} onClick={() => setMenuOpen(false)}><span className="mono">0{index + 1}</span>{link.label}<ArrowIcon /></Link>)}
        <MagneticButton onClick={inquire}>Start a project</MagneticButton>
        <span className="mono mobile-menu-status"><i className="status-dot" /> Available for select projects</span>
      </nav>}
    </header>
  );
}
