'use client';

import Image from 'next/image';
import { useLayoutEffect, useRef } from 'react';
import { gsap } from '@/lib/animations';
import { PlusIcon } from './Icons';

/** A 50 KB art-directed sculpture, composited instead of continuously rendered. */
export default function HeroScene() {
  const ref = useRef(null);
  useLayoutEffect(() => {
    const media = gsap.matchMedia();
    const context = gsap.context(() => {
      media.add('(min-width: 1024px) and (pointer: fine) and (prefers-reduced-motion: no-preference)', () => {
        let inView = false;
        const ambient = gsap.to('.sculpture-float', {
          y: -12, rotation: 1.6, duration: 7, repeat: -1, yoyo: true, ease: 'sine.inOut', paused: true,
        });
        function syncVisibility() {
          if (inView && !document.hidden) ambient.play();
          else ambient.pause();
        }
        const observer = new IntersectionObserver(([entry]) => { inView = entry.isIntersecting; syncVisibility(); });
        observer.observe(ref.current);
        document.addEventListener('visibilitychange', syncVisibility);
        return () => { observer.disconnect(); document.removeEventListener('visibilitychange', syncVisibility); ambient.kill(); };
      });
    }, ref);
    return () => { media.revert(); context.revert(); };
  }, []);
  return (
    <div ref={ref} className="hero-scene" aria-hidden="true">
      <div className="hero-scene-depth">
        <div className="hero-object-reveal">
          <div className="sculpture-float">
            <Image src="/images/hero-sculpture.webp" alt="" fill preload sizes="(max-width: 767px) 150vw, (max-width: 1023px) 110vw, 82vw" quality={85} className="hero-sculpture" />
          </div>
        </div>
      </div>
      <div className="scene-cross scene-cross--top"><PlusIcon /></div>
      <div className="scene-annotation mono"><span className="annotation-line" /><div>FORM_001<span>BEYOND THE EXPECTED</span></div><span className="annotation-coordinate">[ X: 0.84 / Y: 0.26 ]</span></div>
      <span className="scene-axis mono">N—001 &nbsp; / &nbsp; CONTINUOUS EVOLUTION</span>
    </div>
  );
}
