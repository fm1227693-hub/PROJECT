'use client';

import { usePathname } from 'next/navigation';
import { useEffect, useRef } from 'react';
import { gsap } from '@/lib/animations';

/** The only pointer-move listener: cursor + all magnetic buttons share this system. */
export default function CustomCursor() {
  const pathname = usePathname();
  const ref = useRef(null);
  const labelRef = useRef(null);
  useEffect(() => {
    const media = gsap.matchMedia();
    const context = gsap.context(() => {
      media.add('(min-width: 1024px) and (hover: hover) and (pointer: fine) and (prefers-reduced-motion: no-preference)', () => {
        const cursor = ref.current;
        const magnets = new Map();
        let activeMagnet = null;
        let rect = null;
        let visible = false;
        const moveX = gsap.quickTo(cursor, 'x', { duration: 0.25, ease: 'power3.out' });
        const moveY = gsap.quickTo(cursor, 'y', { duration: 0.25, ease: 'power3.out' });
        document.documentElement.classList.add('has-custom-cursor');

        function resetMagnet() {
          if (activeMagnet) {
            const movement = magnets.get(activeMagnet);
            movement?.x(0);
            movement?.y(0);
          }
          activeMagnet = null;
          rect = null;
        }
        function pointerOver(event) {
          const target = event.target;
          const inModal = target.closest('dialog');
          cursor.dataset.hidden = inModal ? 'true' : 'false';
          const interactive = target.closest('a, button, input, textarea, select, [data-cursor]');
          const label = interactive?.dataset.cursor || '';
          cursor.dataset.active = interactive ? 'true' : 'false';
          cursor.dataset.label = label ? 'true' : 'false';
          labelRef.current.textContent = label;
          const nextMagnet = inModal ? null : target.closest('[data-magnetic]');
          if (nextMagnet !== activeMagnet) {
            resetMagnet();
            activeMagnet = nextMagnet;
            if (activeMagnet && !magnets.has(activeMagnet)) {
              magnets.set(activeMagnet, {
                x: gsap.quickTo(activeMagnet, 'x', { duration: 0.35, ease: 'power3.out' }),
                y: gsap.quickTo(activeMagnet, 'y', { duration: 0.35, ease: 'power3.out' }),
              });
            }
          }
        }
        function pointerMove(event) {
          if (!visible) {
            gsap.set(cursor, { x: event.clientX, y: event.clientY, opacity: 1 });
            visible = true;
          }
          moveX(event.clientX);
          moveY(event.clientY);
          if (activeMagnet) {
            rect ||= activeMagnet.getBoundingClientRect();
            const movement = magnets.get(activeMagnet);
            movement.x(gsap.utils.clamp(-8, 8, (event.clientX - rect.left - rect.width / 2) * 0.14));
            movement.y(gsap.utils.clamp(-8, 8, (event.clientY - rect.top - rect.height / 2) * 0.2));
          }
        }
        function pointerLeave() { cursor.style.opacity = '0'; visible = false; resetMagnet(); }
        function invalidateRect() { rect = null; }
        window.addEventListener('pointermove', pointerMove, { passive: true });
        window.addEventListener('pointerover', pointerOver, { passive: true });
        document.documentElement.addEventListener('pointerleave', pointerLeave);
        window.addEventListener('scroll', invalidateRect, { passive: true });
        window.addEventListener('blur', pointerLeave);
        return () => {
          window.removeEventListener('pointermove', pointerMove);
          window.removeEventListener('pointerover', pointerOver);
          document.documentElement.removeEventListener('pointerleave', pointerLeave);
          window.removeEventListener('scroll', invalidateRect);
          window.removeEventListener('blur', pointerLeave);
          resetMagnet();
          moveX.tween.kill(); moveY.tween.kill();
          magnets.forEach(({ x, y }, element) => {
            x.tween.kill(); y.tween.kill();
            gsap.set(element, { clearProps: 'transform' });
          });
          magnets.clear();
          gsap.set(cursor, { opacity: 0 });
          document.documentElement.classList.remove('has-custom-cursor');
        };
      });
    }, ref);
    return () => { media.revert(); context.revert(); };
  }, [pathname]);
  return <div className="cursor-viewport" aria-hidden="true"><div ref={ref} className="custom-cursor"><span className="cursor-shell" /><span ref={labelRef} className="cursor-label mono" /></div></div>;
}
