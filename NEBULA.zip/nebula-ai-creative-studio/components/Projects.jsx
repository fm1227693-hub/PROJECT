'use client';

import { useLayoutEffect, useRef } from 'react';
import { gsap } from '@/lib/animations';
import { scrollToPosition } from '@/lib/scroll';
import { projects } from '@/lib/site';
import ProjectCard from './ProjectCard';
import SectionLabel from './SectionLabel';
import { ArrowIcon } from './Icons';

export default function Projects() {
  const ref = useRef(null);
  const trackRef = useRef(null);
  const windowRef = useRef(null);
  const progressRef = useRef(null);
  const numberRef = useRef(null);
  const previousRef = useRef(null);
  const nextRef = useRef(null);
  const timelineRef = useRef(null);
  const indexRef = useRef(0);

  useLayoutEffect(() => {
    const media = gsap.matchMedia();
    const context = gsap.context(() => {
      media.add({ all: 'all', horizontal: '(min-width: 1024px) and (min-height: 740px) and (pointer: fine)', reduced: '(prefers-reduced-motion: reduce)' }, ({ conditions }) => {
        const cards = gsap.utils.toArray('.project-card', ref.current);
        const track = trackRef.current;
        const viewport = windowRef.current;
        if (conditions.reduced) return;
        const headerReveal = gsap.from('.work-heading-row', { y: 25, opacity: 0, duration: 0.8, ease: 'power3.out', scrollTrigger: { trigger: ref.current, start: 'top 85%', once: true } });
        let horizontal;
        if (conditions.horizontal) {
          const travel = () => Math.max(0, track.scrollWidth - viewport.clientWidth);
          const setProgress = gsap.quickSetter(progressRef.current, 'scaleX');
          horizontal = gsap.to(track, {
            xPercent: () => -travel() / track.scrollWidth * 100,
            ease: 'none',
            scrollTrigger: {
              id: 'nebula-work', trigger: '.work-stage', start: 'top 88px',
              end: () => `+=${travel() + 200}`,
              scrub: 0.65, pin: true, anticipatePin: 1, invalidateOnRefresh: true,
              onUpdate: (self) => {
                setProgress(0.06 + self.progress * 0.94);
                const index = Math.round(self.progress * (projects.length - 1));
                if (index !== indexRef.current) {
                  indexRef.current = index;
                  numberRef.current.textContent = `0${index + 1}`;
                }
                previousRef.current.disabled = index === 0;
                nextRef.current.disabled = index === projects.length - 1;
              },
            },
          });
          timelineRef.current = horizontal;
        }
        cards.forEach((card, index) => {
          const trigger = horizontal && index > 0
            ? { trigger: card, containerAnimation: horizontal, start: 'left 94%', once: true }
            : { trigger: horizontal ? '.work-stage' : card, start: 'top 85%', once: true };
          const reveal = gsap.timeline({ scrollTrigger: trigger, defaults: { ease: 'power3.out' } });
          reveal.fromTo(card.querySelector('.project-reveal'), { clipPath: 'inset(0 100% 0 0)' }, { clipPath: 'inset(0 0% 0 0)', duration: 0.95 })
            .from(card.querySelector('.project-image'), { scale: 1.08, duration: 1.15 }, 0)
            .from(card.querySelector('.project-meta-reveal'), { y: 15, opacity: 0, duration: 0.6 }, 0.38);
        });
        return () => { timelineRef.current = null; headerReveal.kill(); };
      });
    }, ref);
    return () => { media.revert(); context.revert(); };
  }, []);

  function goToProject(index) {
    const trigger = timelineRef.current?.scrollTrigger;
    if (!trigger) return;
    const ratio = Math.max(0, Math.min(1, index / (projects.length - 1)));
    scrollToPosition(trigger.start + (trigger.end - trigger.start) * ratio + 1);
  }

  return (
    <section id="work" ref={ref} className="projects section-shell" aria-labelledby="projects-heading">
      <div className="work-stage">
        <SectionLabel number="02" right="SELECTED EXPLORATIONS / 2025—2026">Selected work</SectionLabel>
        <div className="work-heading-row">
          <h2 id="projects-heading">SELECTED <span className="muted">WORLDS.</span></h2>
          <div className="work-header-aside"><p>Ideas made tangible.<br />Possibilities made real.</p><div className="work-controls"><button ref={previousRef} type="button" aria-label="Previous project" disabled onClick={() => goToProject(indexRef.current - 1)}><ArrowIcon diagonal={false} className="arrow-back" /></button><button ref={nextRef} type="button" aria-label="Next project" onClick={() => goToProject(indexRef.current + 1)}><ArrowIcon diagonal={false} /></button></div></div>
        </div>
        <div ref={windowRef} className="work-window"><div ref={trackRef} className="project-track">{projects.map((project, index) => <ProjectCard key={project.id} project={project} index={index} onFocus={goToProject} />)}</div></div>
        <div className="work-progress mono"><span><span ref={numberRef}>01</span><span className="muted"> / 03</span></span><span className="work-progress-track"><span ref={progressRef} /></span><span className="work-scroll-label">Keep exploring <ArrowIcon diagonal={false} /></span></div>
      </div>
    </section>
  );
}
