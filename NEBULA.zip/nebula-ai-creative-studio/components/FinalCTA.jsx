'use client';

import { useLayoutEffect, useRef } from 'react';
import { gsap } from '@/lib/animations';
import { useStudio } from './StudioProvider';
import MagneticButton from './MagneticButton';
import SectionLabel from './SectionLabel';
import { ArrowIcon } from './Icons';

export default function FinalCTA() {
  const ref = useRef(null);
  const { openContact } = useStudio();
  useLayoutEffect(() => {
    const media = gsap.matchMedia();
    const context = gsap.context(() => {
      media.add('(prefers-reduced-motion: no-preference)', () => {
        const timeline = gsap.timeline({ scrollTrigger: { trigger: ref.current, start: 'top 75%', once: true }, defaults: { ease: 'power3.out' } });
        timeline.from('.cta-atmosphere', { opacity: 0, scale: 0.85, xPercent: -8, duration: 1.4 }, 0)
          .from('.cta-heading-line > span', { yPercent: 105, duration: 0.95, stagger: 0.11 }, 0.1)
          .from('.cta-giant-arrow', { x: -30, y: 30, opacity: 0, duration: 1.1 }, 0.45)
          .from('.cta-subtext', { opacity: 0, y: 15, duration: 0.7 }, 0.8)
          .from('.cta-action', { opacity: 0, y: 15, duration: 0.7 }, 1.02);
      });
    }, ref);
    return () => { media.revert(); context.revert(); };
  }, []);
  return (
    <section id="contact" ref={ref} className="final-cta section-shell" aria-labelledby="cta-heading">
      <div className="cta-atmosphere" aria-hidden="true" />
      <SectionLabel number="04" right="THE NEXT CHAPTER IS UNWRITTEN.">Let’s make it happen</SectionLabel>
      <div className="cta-composition"><h2 id="cta-heading"><span className="cta-heading-line"><span>LET’S BUILD</span></span><span className="cta-heading-line"><span>SOMETHING</span></span><span className="cta-heading-line"><span className="cta-outline">UNEXPECTED<span className="accent">.</span></span></span></h2><ArrowIcon className="cta-giant-arrow" /></div>
      <div className="cta-bottom"><p className="cta-subtext">Have an ambitious idea?<br />Let’s turn it into an experience.</p><div className="cta-action"><MagneticButton onClick={openContact}>Start a project</MagneticButton><span className="mono">GOOD THINGS START WITH A CONVERSATION.</span></div></div>
    </section>
  );
}
