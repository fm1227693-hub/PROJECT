import Link from 'next/link';
import { navigation, site } from '@/lib/site';
import { ArrowIcon, BrandMark } from './Icons';

export default function Footer() {
  return (
    <footer className="footer section-shell">
      <div className="footer-top"><Link href="/#home" className="footer-small-brand" aria-label="NEBULA back to top"><BrandMark /><span className="mono">BEYOND THE<br />EXPECTED.</span></Link><div className="footer-contact"><span className="mono footer-label">SAY HELLO</span><a className="footer-email" href={`mailto:${site.email}`}>{site.email}<ArrowIcon /></a></div><div className="footer-location"><span className="mono footer-label">OUR COORDINATES</span><p>{site.location}</p></div></div>
      <div className="footer-middle"><nav aria-label="Footer navigation" className="footer-nav mono">{navigation.map((link) => <Link className="text-link" key={link.id} href={`/${link.href}`}>{link.label}</Link>)}</nav><div className="footer-socials mono">{site.socials.map((social) => <a className="text-link" key={social.label} href={social.href} target="_blank" rel="noopener noreferrer" aria-label={`${social.label} (opens in a new tab)`}>{social.label}<ArrowIcon /></a>)}</div></div>
      <Link href="/#home" className="footer-wordmark" aria-label="NEBULA back to top"><span>NEBULA</span><sup>®</sup></Link>
      <div className="footer-bottom mono"><span>© 2026 NEBULA STUDIO</span><span className="availability"><i className="status-dot" />Available for select projects</span><Link className="back-top" href="/#home">Back to top<ArrowIcon /></Link></div>
    </footer>
  );
}
