'use client';

import { useLayoutEffect, useRef } from 'react';
import { gsap, motionQueries } from '@/lib/animations';
import HeroScene from './HeroScene';
import MagneticButton from './MagneticButton';
import { ArrowIcon } from './Icons';
import { useStudio } from './StudioProvider';

export default function Hero() {
  const ref = useRef(null);
  const { openContact } = useStudio();
  useLayoutEffect(() => {
    const media = gsap.matchMedia();
    const context = gsap.context(() => {
      media.add(motionQueries, ({ conditions }) => {
        if (conditions.reduced) return;
        const intro = gsap.timeline({ defaults: { ease: 'power3.out' } });
        intro
          .from('.hero-atmosphere', { opacity: 0, duration: 1.1 }, 0)
          .from('.hero-eyebrow', { y: 12, opacity: 0, duration: 0.6 }, 0.12)
          .from('.hero-line-inner', { yPercent: 108, rotation: 2, duration: 1.05, stagger: 0.13 }, 0.28)
          .from('.hero-description', { y: 16, opacity: 0, duration: 0.7 }, 0.98)
          .from('.hero-action', { y: 16, opacity: 0, duration: 0.6, stagger: 0.09 }, 1.14)
          .from('.hero-object-reveal', { opacity: 0, scale: 0.92, x: conditions.desktop ? 55 : 15, duration: 1.35 }, 1.24)
          .from('.scene-annotation, .scene-axis, .scene-cross', { opacity: 0, duration: 0.8, stagger: 0.08 }, 1.8)
          .from('.hero-bottom', { opacity: 0, y: 10, duration: 0.7 }, 1.65);
        if (conditions.desktop) {
          gsap.to('.hero-copy', {
            y: -95, ease: 'none',
            scrollTrigger: { trigger: ref.current, start: 'top top', end: 'bottom top', scrub: 0.8 },
          });
          gsap.to('.hero-heading', {
            scale: 0.955, transformOrigin: 'left center', ease: 'none',
            scrollTrigger: { trigger: ref.current, start: 'top top', end: 'bottom top', scrub: 0.8 },
          });
          gsap.to('.hero-scene-depth', {
            y: -155, scale: 0.91, rotation: -5, ease: 'none',
            scrollTrigger: { trigger: ref.current, start: 'top top', end: 'bottom top', scrub: 1 },
          });
          gsap.to('.hero-atmosphere', {
            y: 110, ease: 'none',
            scrollTrigger: { trigger: ref.current, start: 'top top', end: 'bottom top', scrub: 1 },
          });
        }
      });
    }, ref);
    return () => { media.revert(); context.revert(); };
  }, []);
  return (
    <section ref={ref} id="home" className="hero section-shell" aria-labelledby="hero-heading">
      <div className="hero-atmosphere" aria-hidden="true" />
      <HeroScene />
      <div className="hero-copy">
        <div className="hero-eyebrow mono"><span className="accent-square" /> Independent minds. Extraordinary possibilities.</div>
        <h1 id="hero-heading" className="hero-heading">
          <span className="hero-line"><span className="hero-line-inner">WE BUILD</span></span>
          <span className="hero-line"><span className="hero-line-inner">DIGITAL WORLDS</span></span>
          <span className="hero-line hero-line--muted"><span className="hero-line-inner">FOR THE AI ERA<span className="accent">.</span></span></span>
        </h1>
        <p className="hero-description">A creative studio at the intersection of<br className="desktop-break" /> intelligence, design, and technology.<br /> We make what comes next feel extraordinary.</p>
        <div className="hero-actions">
          <div className="hero-action"><MagneticButton href="#work">Explore our work</MagneticButton></div>
          <div className="hero-action"><MagneticButton onClick={openContact} variant="text">Let’s talk</MagneticButton></div>
        </div>
      </div>
      <div className="hero-bottom mono">
        <a href="#capabilities" className="scroll-cue"><span className="scroll-arrow"><ArrowIcon diagonal={false} /></span>Scroll to explore</a>
        <span className="hero-bottom-center">IMAGINATION, ENGINEERED.</span>
        <span className="availability"><i className="status-dot" />Available for select projects</span>
      </div>
    </section>
  );
}
