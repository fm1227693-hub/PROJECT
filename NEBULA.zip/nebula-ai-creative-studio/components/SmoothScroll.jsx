'use client';

import { useEffect } from 'react';
import Lenis from 'lenis';
import { gsap, ScrollTrigger } from '@/lib/animations';
import { scrollToPosition, setSmoothScroller } from '@/lib/scroll';

export default function SmoothScroll() {
  useEffect(() => {
    const media = gsap.matchMedia();
    media.add('(min-width: 1024px) and (pointer: fine) and (prefers-reduced-motion: no-preference)', () => {
      const lenis = new Lenis({ autoRaf: false, lerp: 0.085, smoothWheel: true, syncTouch: false });
      setSmoothScroller(lenis);
      const update = (time) => lenis.raf(time * 1000);
      lenis.on('scroll', ScrollTrigger.update);
      gsap.ticker.add(update);
      return () => {
        gsap.ticker.remove(update);
        lenis.off('scroll', ScrollTrigger.update);
        lenis.destroy();
        setSmoothScroller(null);
      };
    });

    function handleAnchor(event) {
      if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      const anchor = event.target.closest('a[href]');
      if (!anchor || anchor.target === '_blank' || anchor.hasAttribute('download')) return;
      const url = new URL(anchor.href, window.location.href);
      if (url.origin !== window.location.origin || url.pathname !== window.location.pathname || url.search !== window.location.search || !url.hash) return;
      const hash = url.hash;
      const target = document.getElementById(decodeURIComponent(hash.slice(1)));
      if (!target) return;
      event.preventDefault();
      scrollToPosition(target, { offset: -88 });
      if (window.location.hash !== hash) window.history.pushState(null, '', hash);
      // A skip link also needs to move keyboard focus, not only the viewport.
      if (anchor.classList.contains('skip-link')) target.focus({ preventScroll: true });
    }
    document.addEventListener('click', handleAnchor, true);
    return () => {
      document.removeEventListener('click', handleAnchor, true);
      media.revert();
    };
  }, []);
  return null;
}
