import Link from 'next/link';
import { ArrowIcon } from '@/components/Icons';

export default function NotFound() {
  return <main id="main-content" tabIndex={-1} className="not-found section-shell"><span className="mono accent">404 / UNCHARTED TERRITORY</span><h1>THIS WORLD<br />IS STILL<br /><span className="muted">UNWRITTEN.</span></h1><p>There’s nothing here. But there’s plenty to discover.</p><Link href="/" className="button button--primary"><span>Back to our world</span><ArrowIcon /></Link></main>;
}
