import Hero from '@/components/Hero';
import Capabilities from '@/components/Capabilities';
import Projects from '@/components/Projects';
import Technology from '@/components/Technology';
import FinalCTA from '@/components/FinalCTA';

export default function Home() {
  return <main id="main-content" tabIndex={-1}><Hero /><Capabilities /><Projects /><Technology /><FinalCTA /></main>;
}
