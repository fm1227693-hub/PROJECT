export default function robots() {
  const origin = process.env.NEXT_PUBLIC_SITE_URL || 'https://nebula.studio';
  return { rules: { userAgent: '*', allow: '/' }, sitemap: new URL('/sitemap.xml', origin).href };
}
