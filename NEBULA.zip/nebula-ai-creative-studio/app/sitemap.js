export default function sitemap() {
  const origin = process.env.NEXT_PUBLIC_SITE_URL || 'https://nebula.studio';
  return [{ url: new URL('/', origin).href, changeFrequency: 'monthly', priority: 1 }];
}
