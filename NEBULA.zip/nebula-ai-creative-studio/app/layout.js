import localFont from 'next/font/local';
import { site } from '@/lib/site';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import StudioProvider from '@/components/StudioProvider';
import SmoothScroll from '@/components/SmoothScroll';
import CustomCursor from '@/components/CustomCursor';
import './globals.css';

const display = localFont({ src: '../public/fonts/inter-tight-latin-wght-normal.woff2', variable: '--font-display', display: 'swap', weight: '400 800', preload: true });
const body = localFont({ src: '../public/fonts/manrope-latin-wght-normal.woff2', variable: '--font-body', display: 'swap', weight: '400 700', preload: true });

export const metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://nebula.studio'),
  title: 'NEBULA® — AI Creative Studio',
  description: site.description,
  applicationName: 'NEBULA',
  keywords: ['creative studio', 'AI experiences', 'creative technology', 'digital products', 'interactive design'],
  openGraph: { title: 'NEBULA — We build digital worlds.', description: site.description, type: 'website', locale: 'en_US', images: [{ url: '/images/og-nebula.jpg', width: 1200, height: 630, alt: 'NEBULA — We build digital worlds for the AI era.' }] },
  twitter: { card: 'summary_large_image', title: 'NEBULA — AI Creative Studio', description: site.description, images: ['/images/og-nebula.jpg'] },
  icons: { icon: '/favicon.svg', apple: '/apple-touch-icon.png' },
  robots: { index: true, follow: true },
};

export const viewport = { width: 'device-width', initialScale: 1, themeColor: '#0b0d0c' };

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable}`}>
      <body>
        <a className="skip-link" href="#main-content">Skip to content</a>
        <StudioProvider><SmoothScroll /><Navbar />{children}<Footer /><CustomCursor /></StudioProvider>
      </body>
    </html>
  );
}
